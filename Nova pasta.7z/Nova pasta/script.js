function clique(){

  const nome = document.getElementById("nome").value;
  const hobby = document.getElementById("hobby").value;
  const rede = document.getElementById("rede").value;
  const futebol = document.getElementById("futebol").value;

let objeto = JSON.parse(nome, hobby, rede, futebol);

console.log(objeto);
sessionStorage.setItem(objeto);

window.location.href = "pagina.html";
}